---@enum WheelType
return {
    Sport = 0,
    Muscle = 1,
    Lowrider = 2,
    SUV = 3,
    Offroad = 4,
    Tuner = 5,
    Bike = 6,
    HighEnd = 7,
    BennysOriginal = 8,
    BennysBespoke = 9,
    OpenWheel = 10,
    Street = 11,
    Track = 12,
}